package mx.edu.utez.exambook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExambookApplicationTests {

	@Test
	void contextLoads() {
	}

}
